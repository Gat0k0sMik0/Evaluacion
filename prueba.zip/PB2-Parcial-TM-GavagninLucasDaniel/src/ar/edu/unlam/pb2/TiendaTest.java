package ar.edu.unlam.pb2;

import ar.edu.unlam.pb2.Parcial01.*;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class TiendaTest {

	/**
	 * Resolver los siguientes tests
	 * @throws VendedorDeLicenciaException 
	 */

	@Test (expected = VendedorDeLicenciaException.class)
	public void queAlIntentarAgregarUnaVentaParaUnVendedorDeLicenciaSeLanceUnaVendedorDeLicenciaException() throws VendedorDeLicenciaException {
		//Preparacion
		Vendedor vendedor = new Vendedor("46364928", "Dilan");
		Cliente cliente = new Cliente("20463649287", "Algo");
		Venta venta = new Venta("1", cliente, vendedor);
		Tienda tienda = new Tienda("292929", "MaxiTienda");
		
		
		//Ejecucion
		vendedor.setDeLicencia(true);
		tienda.agregarVenta(venta);
	}

	@Test (expected = VendibleInexistenteException.class)
	public void queAlIntentarAgregarUnVendibleInexistenteAUnaVentaSeLanceUnaVendibleInexistenteException() throws VendibleInexistenteException {
		Vendedor vendedor = new Vendedor("46364928", "Dilan");
		Cliente cliente = new Cliente("20463649287", "Algo");
		Venta venta = new Venta("1", cliente, vendedor);
		Producto prod = new Producto(1, "Hola", 1.5, 1);
		Tienda tienda = new Tienda("292929", "MaxiTienda");
		
		
		//Ejecucion
		tienda.agregarProductoAVenta("1", prod);
	}

	@Test
	public void queSePuedaObtenerUnaListaDeProductosCuyoStockEsMenorOIgualAlPuntoDeReposicion() {
		//Preparacion
		Producto prod = new Producto(1, "Hola", 1.5, 1);
		Producto prod2 = new Producto(1, "Hola", 1.5, 2);
		Producto prod3 = new Producto(1, "Hola", 1.5, 3);
		Producto prod4 = new Producto(1, "Hola", 1.5, 4);
		Tienda tienda = new Tienda("292929", "MaxiTienda");
		ArrayList<Producto> productos = new ArrayList<>() {
			Producto prod = new Producto(1, "Hola", 1.5, 1);
			Producto prod2 = new Producto(1, "Hola", 1.5, 2);
			Producto prod3 = new Producto(1, "Hola", 1.5, 3);
			Producto prod4 = new Producto(1, "Hola", 1.5, 4);
		};
		
		
		//Ejecucion
		tienda.agregarProducto(prod);
		tienda.agregarProducto(prod2);
		tienda.agregarProducto(prod3);
		tienda.agregarProducto(prod4);
		tienda.agregarStock(prod, 1);
		tienda.agregarStock(prod, 2);
		tienda.agregarStock(prod, 3);
		tienda.agregarStock(prod, 2);
		
		
		//Validacion
		assertNotEquals(null, tienda.obtenerProductosCuyoStockEsMenorOIgualAlPuntoDeReposicion());
	}

	@Test
	public void queSePuedaObtenerUnSetDeClientesOrdenadosPorRazonSocialDescendente() {
	}

	@Test
	public void queSePuedaObtenerUnMapaDeVentasRealizadasPorCadaVendedor() {
		// TODO: usar como key el vendedor y Set<Venta> para las ventas
	}

	@Test
	public void queSePuedaObtenerElTotalDeVentasDeServicios() {
	}

	@Test
	public void queAlRealizarLaVentaDeUnProductoElStockSeActualiceCorrectamente() {
	}
}
