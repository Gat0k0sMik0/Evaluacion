package ar.edu.unlam.pb2.Parcial01;

public class VendibleInexistenteException extends Exception {

}
