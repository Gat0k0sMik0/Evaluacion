package ar.edu.unlam.pb2.Parcial01;

public interface Vendible {
	public Integer getCodigo();
	public String getNombre();
	public Double getPrecio();
}
